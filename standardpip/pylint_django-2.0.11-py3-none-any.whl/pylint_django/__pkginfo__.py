"""pkginfo."""
BASE_ID = 51
